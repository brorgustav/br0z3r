import Foundation

// MARK: - broser_core Module
// This module contains core functionality for the broser application

public struct BroserCore {
    public init() {}
    
    public func getVersion() -> String {
        return "1.0.0"
    }
}
