//
//  broserApp.swift
//  broser
//
//  Created by BGW on 2025-06-02.
//

import SwiftUI

@main
struct broserApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


